#include "vstsbsms.h"
#include <stdio.h>

Tempos tempo;

void debug(const char *str, bool close)
{
   static FILE *fp = fopen("debug.txt","w");

   fprintf(fp,str);

   fflush(fp);
   if(close) fclose(fp);
}
