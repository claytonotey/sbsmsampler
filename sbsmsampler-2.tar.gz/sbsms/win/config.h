/* Windows specific config.h */

#undef HAVE_LRINT
#undef HAVE_LRINTF
