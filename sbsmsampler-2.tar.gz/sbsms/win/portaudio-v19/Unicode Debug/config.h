// Automatically generated file 
#define PA_NO_ASIO 
